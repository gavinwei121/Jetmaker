from setuptools import setup, find_packages

setup(
    name='newserve',
    version='1.0.0',
    author='Your Name',
    packages=find_packages(),
    install_requires=[
        # List your dependencies here
    ],
)


